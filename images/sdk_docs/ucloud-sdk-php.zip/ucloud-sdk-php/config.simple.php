<?php
#配置公私钥"
define("PUBLIC_KEY" ,"");
define("PRIVATE_KEY" ,"");
define("PROJECT_ID" ,""); #项目ID 请从dashbord 获取 默认项目可以为空

#配置api地址'''
define("BASE_URL" ,"https://api.ucloud.cn");

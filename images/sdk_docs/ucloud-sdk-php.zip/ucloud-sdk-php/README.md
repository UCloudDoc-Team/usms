# UCloud短信包PHP-SDK使用说明

### 准备工作
#### 1. 拷贝 config.simple.php 到 config.php
```
cd ucloud-sdk-php
cp config.simple.php config.php
```

#### 2. 配置公私钥及项目ID
1. 公私钥请到用户中心获取(全部产品-操作管理-API产品)
+ public_key  = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
+ private_key = "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
2. 项目ID请从官网资源统计中查看(格式为 org-xxxxxx)
+ project_id = "xxxxxx"

#### 3. 配置api地址，要求有外网IP的主机使用
+ base_url = "https://api.ucloud.cn"

### 发送短信及获取回执信息
#### 1. 发送短信
#### 脚本：send_usms_message.php 使用示范:
```
php send_usms_message.php "13777777777|137xxxxxxxx|138xxxxxxxx" "UTA1904220001" "123456|10" "test"
```

#### 说明 - 命令行各参数含义分别对应如下:
+ 手机号列表：支持国际及国内短信，国际短信使用(86)18511111111格式，需要在手机号码前面带上国际电话区号，格式为"137xxxxxxxx|136xxxxxxxx|177xxxxxxxx"，以|分隔每个手机号
+ 模板ID: 首次使用，需要在UCloud控制台申请模板，审核通过后，将模板ID传入到该处.
+ 模板参数列表：短信模板中可传入变量，申请的时候模板中有几个变量，则需要传入几个。格式为"123456|10"，以|分隔每个参数；当申请的模板无可变参数时，可不填。
+ 签名：首次使用，需要在UCloud控制台申请签名，审核通过后，将签名传入该处。首次申请的签名为默认签名，有默认签名存在时，该参数可不填

#### 2.获取短信回执
#### 脚本：get_usms_send_receipt.php 使用示范:
```
php get_usms_send_receipt.php "e64b3d48-b5b4-405e-9174-596531xxxxxx|d08e36ac-bbfd-4813-9775-dc2a1cxxxxxx"
```

#### 说明 - 命令行各参数说明：
+ 发送时返回的SessionNo列表: 以|分隔
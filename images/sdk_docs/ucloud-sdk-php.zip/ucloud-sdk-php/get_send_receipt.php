<?php

include_once "config.php";
include_once "sdk.php";

if($argc < 3){
    print "php ./get_send_receipt.php 'c7d1d1d1-63a8-4f43-b123-263486e916f8|c7d1d1d1-63a8-4f43-b123-263486e916f8'".PHP_EOL;
    exit;
}

$conn = new UcloudApiClient(BASE_URL, PUBLIC_KEY, PRIVATE_KEY, PROJECT_ID);
$params['Action'] = "GetUSMSSendReceipt";

$receipts = explode("|", $argv[1]);
foreach($receipts as $key => $val){
    $params["SessionNoSet.".$key] = $val;
}

print_r($response = $conn->get("/", $params));
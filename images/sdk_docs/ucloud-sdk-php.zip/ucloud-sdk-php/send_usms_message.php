<?php

include_once "config.php";
include_once "sdk.php";

if($argc < 3){
    print "php ./send_usms_message.php '1377777777777|137888888888' 'UTG1904240000' '123456|10' 'test'".PHP_EOL;
    exit;
}

$conn = new UcloudApiClient(BASE_URL, PUBLIC_KEY, PRIVATE_KEY, PROJECT_ID);
$params['Action'] = "SendUSMSMessage";

//手机号码列表
$phones = explode("|", $argv[1]);
foreach($phones as $key => $val){
    $params["PhoneNumbers.".$key] = $val;
}

//申请的模板ID
$params["TemplateId"] = $argv[2];

//模板参数列表
$templates = explode("|", $argv[3]);
foreach($templates as $key => $val) {
    $params["TemplateParams.".$key] = $val;
}

//申请的签名
$params["SigContent"] = $argv[4];

print_r($response = $conn->get("/", $params));